# SLV GST Services — Next.js website (static, GitHub Pages)

React + Next.js 14 (App Router), exported as a static site. 17 pages and 13 articles, with built-in SEO.

## 1. Edit your details
Open `src/lib/site.ts` and change `whatsapp`, `phone`, `email`.
Optional: add a Formspree URL as `NEXT_PUBLIC_FORM_ENDPOINT` so the contact form sends email.
Without it, the form opens WhatsApp with the message filled in.

## 2. Run locally
```
npm install
npm run dev        # http://localhost:3000
npm run build      # creates the static site in /out
```

## 3. Put it live on GitHub
1. Create a new GitHub repository and push this folder to the `main` branch.
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. Every push to `main` builds and publishes the site (`.github/workflows/deploy.yml`).
4. URL: `https://<username>.github.io/<repo>/`.
   Name the repo `<username>.github.io` to get `https://<username>.github.io/` without a sub-path.

### Custom domain (best for SEO)
1. Repo → Settings → Pages → Custom domain, and add DNS records as GitHub shows.
2. Repo → Settings → Secrets and variables → Actions → **Variables**: add `SITE_URL` = `https://yourdomain.com`.
3. Re-run the workflow. Canonical URLs, sitemap and schema will use your domain.

## 4. SEO already included
Unique title and meta description per page, canonical URLs, Open Graph and Twitter tags,
`sitemap.xml`, `robots.txt`, JSON-LD schema (business, service, article, FAQ, breadcrumbs),
clean URLs, semantic headings, fast static pages.

After launch: add the site in Google Search Console and submit `/sitemap.xml`,
create a Google Business Profile, and publish new articles regularly.

## 5. Add or edit content
Pages are in `content/pages.json` and articles in `content/posts.json`
(`md` field uses Markdown; lines starting with `Q:` and `A:` become FAQs).
Add a new object, commit and push. The sitemap and pages update automatically.

## Before showing a client
Replace placeholder contact details, confirm "Serving Since 2016", add a real logo and photos,
and have the tax articles and legal pages reviewed by a CA or lawyer.
