const base = process.env.NEXT_PUBLIC_BASE_PATH || '';
/** @type {import('next').NextConfig} */
export default {
  output: 'export',          // static site for GitHub Pages
  trailingSlash: true,       // /gst-registration/ like a normal website
  basePath: base || undefined,
  images: { unoptimized: true },
  reactStrictMode: true,
  eslint: { ignoreDuringBuilds: true },
};
