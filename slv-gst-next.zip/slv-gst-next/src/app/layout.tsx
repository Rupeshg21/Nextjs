import type { Metadata, Viewport } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { SITE_URL, site } from '@/lib/site';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL + '/'),
  title: { default: `${site.name} | GST, Income Tax, Accounting & PAN Services in India`, template: `%s | ${site.name}` },
  description: 'GST registration, GST return filing, income tax return assistance, bookkeeping, accounting and PAN card services for individuals and businesses across India.',
  applicationName: site.name,
  authors: [{ name: site.name }],
  formatDetection: { telephone: false },
};
export const viewport: Viewport = { themeColor: '#102A43', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&family=Inter:wght@400;500;600&family=Poppins:wght@600;700&display=swap" />
      </head>
      <body>
        <a className="skip" href="#top">Skip to content</a>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
