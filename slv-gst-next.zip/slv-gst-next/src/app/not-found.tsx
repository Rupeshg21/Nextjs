import { ServiceGrid } from '@/components/Bits';
export default function NotFound() {
  return (
    <main id="top">
      <div className="pagehead"><div className="wrap"><h1>Page not found</h1><p>The page you wanted is not here. Try one of our services.</p></div></div>
      <div className="wrap sec"><ServiceGrid /></div>
    </main>
  );
}
