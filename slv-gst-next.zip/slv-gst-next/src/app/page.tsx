import Link from 'next/link';
import { Icon, WaIcon } from '@/components/Icons';
import { Cta, FaqList, JsonLd, PostCard, ServiceGrid } from '@/components/Bits';
import { findPage, posts } from '@/lib/content';
import { parse } from '@/lib/md';
import { meta, orgSchema, siteSchema, faqSchema } from '@/lib/seo';
import { site, waLink } from '@/lib/site';

export const metadata = meta({
  title: `${site.name} | GST, Income Tax, Accounting & PAN Services in India`,
  desc: 'GST registration, GST return filing, income tax return assistance, bookkeeping, accounting and PAN card services for individuals and businesses across India.',
  path: '/',
});

const steps = [['Understand', 'We listen to what you need and explain the scope.'], ['Collect documents', 'You share a clear checklist of documents.'], ['Verify', 'We check every detail before we start.'], ['Prepare', 'Forms, returns or records are prepared.'], ['Review', 'You review the work. Nothing goes ahead without you.'], ['Deliver', 'We complete the filing or hand over the records.']];
const why = [['shield', 'Clear scope and fees', 'You know what is included and what government charges apply, before work starts.'], ['check', 'Documents checked twice', 'Names, numbers and dates are verified against your documents to avoid rejections and notices.'], ['user', 'Plain-language support', 'We explain each step in simple words, in English, Telugu or Hindi.'], ['clock', 'Deadlines tracked', 'We remind you of due dates so returns are not filed late.']];

export default function Home() {
  const faqs = parse(findPage('home')!.md).faqs;
  return (
    <main id="top">
      <JsonLd graph={[orgSchema(), siteSchema(), faqSchema(faqs)]} />
      <section className="hero">
        <div className="wrap">
          <div className="fade">
            <span className="badge">SERVING SINCE 2016</span>
            <h1>Your GST, Tax &amp; Accounting. <em>Made Simpler.</em></h1>
            <p>We provide reliable and affordable GST, tax, accounting and documentation services for individuals, startups and businesses across India.</p>
            <div className="btns">
              <a className="btn btn-green" href={waLink()} target="_blank" rel="noopener"><WaIcon /> WhatsApp Us</a>
              <Link className="btn btn-line" href="/services/">Explore Our Services &rarr;</Link>
            </div>
            <div className="hand">Simple Process · Clear Guidance · Reliable Support</div>
          </div>
          <div className="hero-visual fade d2" aria-hidden="true">
            <div className="hv"><i>✓</i><div><b>GST Registration</b><small>Documents verified</small></div></div>
            <div className="hv hv2"><i>✓</i><div><b>Income Tax Return</b><small>Reviewed with you first</small></div></div>
            <div className="hv hv3"><i>✓</i><div><b>PAN Services</b><small>Application tracked</small></div></div>
          </div>
        </div>
      </section>
      <div className="trust"><span>GST Registration &amp; Returns</span><span>Income Tax Returns</span><span>Bookkeeping &amp; Accounting</span><span>PAN Card Services</span></div>

      <section className="sec pale"><div className="wrap">
        <h2 className="sec-title">What we do</h2><p className="sec-sub">GST, income tax, accounting and PAN support under one roof.</p>
        <ServiceGrid />
      </div></section>

      <section className="sec"><div className="wrap">
        <h2 className="sec-title">Why choose SLV GST Services</h2><p className="sec-sub">Compliance is stressful when you are unsure what to do. We make it a clear, step-by-step process.</p>
        <div className="grid g4">
          {why.map((w) => (<div className="card col fade" key={w[1]}><span className="ico"><Icon name={w[0]} /></span><h3>{w[1]}</h3><p>{w[2]}</p></div>))}
        </div>
      </div></section>

      <section className="sec pale"><div className="wrap">
        <h2 className="sec-title">How it works</h2><p className="sec-sub">The same six steps for every service.</p>
        <ol className="steps">{steps.map((s) => (<li key={s[0]}><b>{s[0]}</b><span>{s[1]}</span></li>))}</ol>
      </div></section>

      <section className="sec"><div className="wrap">
        <div className="rev-head"><div><h2>Latest from the Knowledge Base</h2><p>Practical guides on ITR, GST, accounting and PAN.</p></div><Link className="btn btn-green" href="/knowledge-base/">All articles</Link></div>
        <div className="grid g3" style={{ marginTop: 20 }}>{posts.slice(0, 3).map((p) => <PostCard key={p.slug} p={p} />)}</div>
      </div></section>

      <section className="sec pale"><div className="wrap narrow"><h2 className="sec-title">Common questions</h2><FaqList faqs={faqs} /></div></section>
      <Cta title="Need help with GST, tax or PAN?" />
    </main>
  );
}
