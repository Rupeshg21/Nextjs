import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Aside, Cta, FaqList, JsonLd, PageHead, PostCard, ServiceGrid } from '@/components/Bits';
import ContactForm from '@/components/ContactForm';
import { findPage, findPost, pages, posts } from '@/lib/content';
import { parse } from '@/lib/md';
import { articleSchema, crumbSchema, faqSchema, isService, meta, serviceSchema } from '@/lib/seo';
import { catNames } from '@/lib/site';

export const dynamicParams = false;
export function generateStaticParams() {
  return [...pages.filter((p) => p.slug !== 'home'), ...posts].map((e) => ({ slug: e.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const post = findPost(params.slug);
  if (post) return meta({ title: post.title, desc: post.desc, path: `/${post.slug}/`, type: 'article', date: post.date });
  const page = findPage(params.slug);
  if (!page) return {};
  return meta({ title: page.st || page.title, desc: page.desc, path: `/${page.slug}/` });
}

const fmt = (d: string) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });

export default function Entry({ params }: { params: { slug: string } }) {
  const post = findPost(params.slug);
  const page = post ? undefined : findPage(params.slug);
  const e = post || page;
  if (!e || (page && page.slug === 'home')) notFound();
  const { html, faqs, toc } = parse(e.md);
  const crumbs = post
    ? [{ name: 'Home', path: '/' }, { name: 'Knowledge Base', path: '/knowledge-base/' }, { name: e.title, path: `/${e.slug}/` }]
    : [{ name: 'Home', path: '/' }, { name: e.title, path: `/${e.slug}/` }];
  const graph: object[] = [crumbSchema(crumbs)];
  if (faqs.length) graph.push(faqSchema(faqs));
  if (post) graph.push(articleSchema(post)); else if (isService(e.slug)) graph.push(serviceSchema(e));

  const full = ['services', 'knowledge-base'].includes(e.slug);
  const related = post ? posts.filter((p) => p.cat === post.cat && p.slug !== post.slug).slice(0, 3) : [];
  const tocAll = post && toc.length + (faqs.length ? 1 : 0) >= 3 ? [...toc, ...(faqs.length ? [{ id: 'faqs', text: 'Frequently asked questions' }] : [])] : [];

  return (
    <main id="top">
      <JsonLd graph={graph} />
      <PageHead title={e.title} crumbs={crumbs}
        sub={post ? `${catNames[post.cat]} · Last updated ${fmt(post.date)} · By SLV GST Services` : e.desc} />
      <div className={'wrap article-wrap' + (full ? ' full' : '')}>
        <article className="entry">
          {tocAll.length > 0 && (
            <nav className="toc"><b>In this article</b><ol>{tocAll.map((t) => (<li key={t.id}><a href={`#${t.id}`}>{t.text}</a></li>))}</ol></nav>
          )}
          <div dangerouslySetInnerHTML={{ __html: html }} />
          {e.slug === 'contact' && <ContactForm />}
          {e.slug === 'services' && <ServiceGrid />}
          {e.slug === 'knowledge-base' && Object.keys(catNames).map((c) => (
            <section key={c}>
              <h2 id={c}>{catNames[c]}</h2>
              <div className="grid g3">{posts.filter((p) => p.cat === c).map((p) => <PostCard key={p.slug} p={p} />)}</div>
            </section>
          ))}
          {faqs.length > 0 && (<><h2 id="faqs">Frequently asked questions</h2><FaqList faqs={faqs} /></>)}
          {post && <div className="note"><b>Please note:</b> This article is general information, not tax or legal advice. Rules, forms and due dates change, so please confirm on the official portal or <Link href="/contact/">contact us</Link> for help with your case.</div>}
        </article>
        {!full && <Aside />}
      </div>
      {related.length > 0 && (<section className="sec pale"><div className="wrap"><h2>Related articles</h2><div className="grid g3">{related.map((p) => <PostCard key={p.slug} p={p} />)}</div></div></section>)}
      {e.slug !== 'contact' && <Cta />}
    </main>
  );
}
