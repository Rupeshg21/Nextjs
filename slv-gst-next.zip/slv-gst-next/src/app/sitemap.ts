import type { MetadataRoute } from 'next';
import { LAST_UPDATED, pages, posts } from '@/lib/content';
import { SITE_URL } from '@/lib/site';

export const dynamic = 'force-static';
export default function sitemap(): MetadataRoute.Sitemap {
  const top = ['services', 'about', 'pricing', 'contact', 'knowledge-base'];
  const pri = (s: string) => (s === 'home' ? 1 : top.includes(s) || pages.find((p) => p.slug === s)?.slug.includes('-') ? 0.8 : 0.5);
  return [
    { url: `${SITE_URL}/`, lastModified: LAST_UPDATED, changeFrequency: 'weekly', priority: 1 },
    ...pages.filter((p) => p.slug !== 'home').map((p) => ({ url: `${SITE_URL}/${p.slug}/`, lastModified: LAST_UPDATED, changeFrequency: 'monthly' as const, priority: pri(p.slug) })),
    ...posts.map((p) => ({ url: `${SITE_URL}/${p.slug}/`, lastModified: p.date, changeFrequency: 'monthly' as const, priority: 0.7 })),
  ];
}
