import Link from 'next/link';
import { Icon, WaIcon } from './Icons';
import { services, waLink, catNames } from '@/lib/site';
import type { Post } from '@/lib/content';
import type { Faq } from '@/lib/md';

export function JsonLd({ graph }: { graph: object[] }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }) }} />;
}

export function Breadcrumbs({ items }: { items: { name: string; path: string }[] }) {
  if (items.length < 2) return null;
  return (
    <nav className="crumbs" aria-label="Breadcrumb">
      {items.map((x, i) => (
        <span key={x.path}>{i > 0 && ' / '}{i < items.length - 1 ? <Link href={x.path}>{x.name}</Link> : <span>{x.name}</span>}</span>
      ))}
    </nav>
  );
}

export function PageHead({ title, sub, crumbs }: { title: string; sub?: string; crumbs: { name: string; path: string }[] }) {
  return (
    <div className="pagehead"><div className="wrap"><Breadcrumbs items={crumbs} /><h1>{title}</h1>{sub && <p className={sub.startsWith('Last updated') ? 'meta' : ''}>{sub}</p>}</div></div>
  );
}

export function ServiceGrid() {
  return (
    <div className="grid g4 svc-grid">
      {services.map((s, i) => (
        <Link key={s.slug} className={`card fade d${(i % 4) as 0 | 1 | 2 | 3}`} href={`/${s.slug}/`}>
          <span className="ico"><Icon name={s.icon} /></span>
          <div><h3>{s.title}</h3><p>{s.desc}</p></div>
        </Link>
      ))}
    </div>
  );
}

export function PostCard({ p }: { p: Post }) {
  return (
    <article className="pcard">
      <small>{catNames[p.cat]}</small>
      <h3><Link href={`/${p.slug}/`}>{p.title}</Link></h3>
      <p>{p.desc}</p>
      <Link className="more" href={`/${p.slug}/`}>Read article &rarr;</Link>
    </article>
  );
}

export function FaqList({ faqs }: { faqs: Faq[] }) {
  return (
    <div className="faq">
      {faqs.map((f) => (<details key={f.q}><summary>{f.q}</summary><p dangerouslySetInnerHTML={{ __html: f.aHtml }} /></details>))}
    </div>
  );
}

export function Cta({ title = 'Need assistance? Contact SLV GST Services.' }: { title?: string }) {
  return (
    <section className="sec"><div className="wrap"><div className="cta-box cta-wide">
      <div><h3>{title}</h3><p>Tell us what you need. We will explain the process, documents and fees before we begin.</p></div>
      <div className="btns"><a className="btn btn-green" target="_blank" rel="noopener" href={waLink()}><WaIcon /> WhatsApp Us</a><Link className="btn btn-line" href="/contact/">Send an enquiry</Link></div>
    </div></div></section>
  );
}

export function Aside() {
  return (
    <aside className="aside">
      <div className="cta-box"><h3>Talk to us</h3><p>Get quick guidance on documents, process and fees.</p><a className="btn btn-green" target="_blank" rel="noopener" href={waLink()}><WaIcon /> WhatsApp Us</a></div>
      <div className="aside-links"><h4>Our services</h4><ul>{services.map((s) => (<li key={s.slug}><Link href={`/${s.slug}/`}>{s.title}</Link></li>))}</ul></div>
    </aside>
  );
}
