'use client';
import Link from 'next/link';
import { useState } from 'react';
import { services, site, waLink } from '@/lib/site';

export default function ContactForm() {
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'err'>('idle');
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const v = (k: string) => String(fd.get(k) || '').trim();
    const mobile = v('mobile').replace(/[^0-9+]/g, '');
    if (!v('name') || mobile.length < 10 || !v('msg') || !fd.get('consent')) { setState('err'); return; }
    if (v('website')) return; // honeypot
    const text = `Hello SLV GST Services,\nName: ${v('name')}\nMobile: ${mobile}\nEmail: ${v('email')}\nService: ${v('service')}\nPrefers: ${v('via')}\n\n${v('msg')}`;
    if (site.formEndpoint) {
      setState('sending');
      try {
        const r = await fetch(site.formEndpoint, { method: 'POST', headers: { Accept: 'application/json' }, body: fd });
        setState(r.ok ? 'sent' : 'err');
      } catch { setState('err'); }
    } else {
      window.open(waLink(text), '_blank', 'noopener');
      setState('sent');
    }
  }
  return (
    <form className="cf" onSubmit={onSubmit} id="enquiry">
      {state === 'sent' && <div className="notice-ok">Thank you. Your enquiry is ready and we will contact you shortly.</div>}
      {state === 'err' && <div className="notice-err">Please enter your name, a valid mobile number, your requirement and accept the privacy consent.</div>}
      <input type="text" name="website" className="hp" tabIndex={-1} autoComplete="off" aria-hidden="true" />
      <label>Full name *<input name="name" required /></label>
      <label>Mobile number *<input name="mobile" type="tel" required /></label>
      <label>Email address (optional)<input name="email" type="email" /></label>
      <label>Service required *<select name="service">{services.map((s) => <option key={s.slug}>{s.title}</option>)}<option>Other</option></select></label>
      <label>Brief description of your requirement *<textarea name="msg" rows={4} required /></label>
      <label>Preferred contact method<select name="via"><option>WhatsApp</option><option>Phone call</option><option>Email</option></select></label>
      <label className="chk"><input type="checkbox" name="consent" value="1" /> I agree to be contacted about this enquiry and accept the <Link href="/privacy-policy/">Privacy Policy</Link>.</label>
      <button className="btn btn-green" type="submit" disabled={state === 'sending'}>{state === 'sending' ? 'Sending…' : site.formEndpoint ? 'Send enquiry' : 'Send on WhatsApp'}</button>
      <p className="fine">Do not share passwords, OTPs or tax documents in this form. We will tell you how to send documents securely.</p>
    </form>
  );
}
