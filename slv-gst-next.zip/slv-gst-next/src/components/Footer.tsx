import Link from 'next/link';
import { Logo, WaIcon } from './Icons';
import { site, waLink } from '@/lib/site';

export default function Footer() {
  return (
    <>
      <footer className="site-footer">
        <div className="wrap ft">
          <div>
            <Link className="brand" href="/"><Logo light /><span><b>{site.name}</b><small>{site.tagline}</small></span></Link>
            <p><span className="badge">{site.since}</span></p>
          </div>
          <div><h4>Quick Links</h4>
            <ul><li><Link href="/">Home</Link></li><li><Link href="/services/">Services</Link></li><li><Link href="/pricing/">Pricing</Link></li><li><Link href="/about/">About</Link></li><li><Link href="/contact/">Contact</Link></li></ul>
          </div>
          <div><h4>Resources</h4>
            <ul><li><Link href="/knowledge-base/">Knowledge Base</Link></li><li><Link href="/privacy-policy/">Privacy Policy</Link></li><li><Link href="/terms/">Terms</Link></li><li><Link href="/disclaimer/">Disclaimer</Link></li></ul>
          </div>
          <div><h4>Contact</h4>
            <p>{site.phone}<br />{site.email}</p>
          </div>
        </div>
        <div className="wrap copy"><span>&copy; {new Date().getFullYear()} {site.name}. All rights reserved.</span><span>GST &middot; Tax &middot; Accounting &middot; PAN Services</span></div>
        <div className="wrap fine-ft">{site.name} is an independent service provider and is not affiliated with any government authority. Content on this site is for general information only.</div>
      </footer>
      <a className="btn btn-green wa-float" target="_blank" rel="noopener" href={waLink()}><WaIcon /> WhatsApp</a>
    </>
  );
}
