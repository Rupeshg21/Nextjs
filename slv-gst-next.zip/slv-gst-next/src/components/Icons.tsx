const P: Record<string, string> = {
  doc: 'M6 3h8l4 4v14H6zM14 3v4h4M9 12h6M9 16h6',
  check: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8 12l3 3 5-6',
  chart: 'M4 20V10M10 20V4M16 20v-8M22 20H2',
  book: 'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM8 7h7',
  id: 'M3 7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 11a2 2 0 1 0 0 .01M14 10h4M14 14h4M6 16c1-2 5-2 6 0',
  shield: 'M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6zM9 12l2 2 4-4',
  user: 'M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21c1-5 15-5 16 0',
  tag: 'M3 12V3h9l9 9-9 9zM7.5 7.5h.01',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
};
export function Icon({ name }: { name: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d={P[name] || P.doc} /></svg>
  );
}
export function WaIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" style={{ fill: 'currentColor', stroke: 'none' }}>
      <path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.1-1.3A10 10 0 1 0 12 2zm0 2a8 8 0 1 1-4.1 14.9l-.3-.2-2.5.7.7-2.4-.2-.3A8 8 0 0 1 12 4zm-3 3.5c-.3.3-.8.9-.8 1.9s.8 2.2 1 2.4c.2.2 1.8 2.9 4.5 3.9 2.2.8 2.6.6 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2l-1.8-.9c-.3-.1-.4-.1-.6.1l-.8 1c-.2.2-.3.2-.6.1-.9-.4-2.2-1.1-3-2.4-.2-.3.2-.3.6-1.1.1-.2 0-.4 0-.5l-.8-1.9c-.2-.5-.4-.4-.6-.4z" />
    </svg>
  );
}
export function Logo({ light = false }: { light?: boolean }) {
  const c = light ? '#3FD49B' : '#147D59';
  return (
    <svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true">
      <rect x="3" y="22" width="7" height="14" fill={c} /><rect x="14" y="14" width="7" height="22" fill={c} /><rect x="25" y="5" width="7" height="31" fill={c} />
    </svg>
  );
}
