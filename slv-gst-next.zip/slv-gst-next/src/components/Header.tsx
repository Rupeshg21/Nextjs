'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Logo, WaIcon } from './Icons';
import { services, site, waLink } from '@/lib/site';

export default function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="site-header">
      <div className="wrap hd">
        <Link className="brand" href="/" onClick={close}>
          <Logo />
          <span><b>{site.name}</b><small>{site.tagline}</small></span>
        </Link>
        <span className="badge hd-badge">{site.since}</span>
        <button className="menu-btn" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}><span /><span /><span /></button>
        <nav className={'nav' + (open ? ' open' : '')} aria-label="Primary">
          <ul>
            <li><Link href="/" onClick={close}>Home</Link></li>
            <li className="menu-item-has-children">
              <Link href="/services/" onClick={close}>Services</Link>
              <ul className="sub">
                {services.map((s) => (<li key={s.slug}><Link href={`/${s.slug}/`} onClick={close}>{s.title}</Link></li>))}
              </ul>
            </li>
            <li><Link href="/knowledge-base/" onClick={close}>Knowledge Base</Link></li>
            <li><Link href="/about/" onClick={close}>About</Link></li>
            <li><Link href="/pricing/" onClick={close}>Pricing</Link></li>
            <li><Link href="/contact/" onClick={close}>Contact</Link></li>
          </ul>
        </nav>
        <a className="btn btn-green" href={waLink()} target="_blank" rel="noopener"><WaIcon /> Get in Touch</a>
      </div>
    </header>
  );
}
