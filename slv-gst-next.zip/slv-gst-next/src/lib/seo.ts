import type { Metadata } from 'next';
import { SITE_URL, site, services } from './site';
import type { Faq } from './md';

export const url = (path: string) => `${SITE_URL}${path}`;
export const isService = (slug: string) => services.some((s) => s.slug === slug);

export function meta(opts: { title: string; desc: string; path: string; type?: 'website' | 'article'; date?: string }): Metadata {
  const full = opts.title.includes('SLV GST') ? opts.title : `${opts.title} | ${site.name}`;
  return {
    title: { absolute: full },
    description: opts.desc,
    alternates: { canonical: url(opts.path) },
    robots: { index: true, follow: true, 'max-image-preview': 'large' } as Metadata['robots'],
    openGraph: {
      title: full, description: opts.desc, url: url(opts.path), siteName: site.name, locale: 'en_IN', type: opts.type || 'website',
      ...(opts.date ? { publishedTime: opts.date, modifiedTime: opts.date } : {}),
    },
    twitter: { card: 'summary_large_image', title: full, description: opts.desc },
  };
}

export const orgSchema = () => ({
  '@type': 'ProfessionalService', '@id': url('/#org'), name: site.name, url: url('/'), slogan: site.tagline,
  areaServed: { '@type': 'Country', name: 'India' }, email: site.email, telephone: site.phone,
  description: 'GST, income tax, bookkeeping, accounting and PAN services for individuals and businesses.',
});
export const siteSchema = () => ({ '@type': 'WebSite', url: url('/'), name: site.name, inLanguage: 'en-IN' });
export const faqSchema = (faqs: Faq[]) => ({
  '@type': 'FAQPage',
  mainEntity: faqs.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.aPlain } })),
});
export const crumbSchema = (c: { name: string; path: string }[]) => ({
  '@type': 'BreadcrumbList',
  itemListElement: c.map((x, i) => ({ '@type': 'ListItem', position: i + 1, name: x.name, item: url(x.path) })),
});
export const articleSchema = (p: { title: string; desc: string; slug: string; date: string }) => ({
  '@type': 'Article', headline: p.title, description: p.desc, datePublished: p.date, dateModified: p.date, inLanguage: 'en-IN',
  mainEntityOfPage: url(`/${p.slug}/`), author: { '@type': 'Organization', name: site.name }, publisher: { '@id': url('/#org') },
});
export const serviceSchema = (p: { title: string; desc: string; slug: string }) => ({
  '@type': 'Service', name: p.title, description: p.desc, url: url(`/${p.slug}/`), areaServed: 'India', provider: { '@id': url('/#org') },
});
