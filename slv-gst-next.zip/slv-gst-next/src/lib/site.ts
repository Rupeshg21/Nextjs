export const BASE = process.env.NEXT_PUBLIC_BASE_PATH || '';
const ORIGIN = (process.env.NEXT_PUBLIC_SITE_URL || 'https://example.github.io').replace(/\/$/, '');
export const SITE_URL = ORIGIN + BASE; // no trailing slash

// ====== EDIT THESE ======
export const site = {
  name: 'SLV GST Services',
  tagline: 'Your Business Compliance, Made Simple.',
  whatsapp: '910000000000', // country code + number, no + or spaces
  phone: '+91 00000 00000',
  email: 'info@example.com',
  formEndpoint: process.env.NEXT_PUBLIC_FORM_ENDPOINT || '', // e.g. a Formspree URL (optional)
  since: 'Serving Since 2016',
};

export const waLink = (msg = 'Hello SLV GST Services, I need help with ') =>
  `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(msg)}`;

export const services = [
  { title: 'GST Services', desc: 'Registration, compliance, returns and more.', slug: 'gst-services', icon: 'doc' },
  { title: 'GST Registration', desc: 'New registration, amendment and cancellation.', slug: 'gst-registration', icon: 'check' },
  { title: 'GST Return Filing', desc: 'GSTR-1, GSTR-3B and other returns.', slug: 'gst-return-filing', icon: 'doc' },
  { title: 'Income Tax Return Assistance', desc: 'ITR filing and tax support for individuals and businesses.', slug: 'income-tax-return-filing', icon: 'doc' },
  { title: 'Bookkeeping', desc: 'Accurate and organized financial records.', slug: 'bookkeeping-services', icon: 'book' },
  { title: 'Business Accounting', desc: 'Monthly or quarterly accounting and MIS reports.', slug: 'business-accounting', icon: 'chart' },
  { title: 'Audit Preparation Support', desc: 'Record preparation and CA coordination.', slug: 'audit-preparation-support', icon: 'check' },
  { title: 'PAN Card Services', desc: 'New PAN, correction, reprint and status tracking.', slug: 'pan-card-services', icon: 'id' },
];
export const catNames: Record<string, string> = {
  'income-tax-itr': 'Income Tax & ITR',
  accounting: 'Accounting',
  gst: 'GST',
  'pan-services': 'PAN Services',
};
