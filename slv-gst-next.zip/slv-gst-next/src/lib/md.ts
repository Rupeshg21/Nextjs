import { Marked } from 'marked';
import { BASE } from './site';

const slugify = (s: string) => s.toLowerCase().replace(/<[^>]+>/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const m = new Marked({ gfm: true });
m.use({
  renderer: {
    heading(text: string, level: number) {
      return `<h${level} id="${slugify(text)}">${text}</h${level}>\n`;
    },
    link(href: string, _title: string | null | undefined, text: string) {
      if (href.startsWith('/')) return `<a href="${BASE}${href}">${text}</a>`;
      return `<a href="${href}" target="_blank" rel="noopener nofollow">${text}</a>`;
    },
    table(header: string, body: string) {
      return `<div class="tbl"><table><thead>${header}</thead><tbody>${body}</tbody></table></div>\n`;
    },
  },
});

export type Faq = { q: string; a: string; aHtml: string; aPlain: string };

export function parse(md: string) {
  const faqs: Faq[] = [];
  const keep: string[] = [];
  for (const l of md.split(/\r?\n/)) {
    const q = l.match(/^Q: (.+)/);
    if (q) { faqs.push({ q: q[1], a: '', aHtml: '', aPlain: '' }); continue; }
    const a = l.match(/^A: (.+)/);
    if (a && faqs.length) { faqs[faqs.length - 1].a = a[1]; continue; }
    keep.push(l);
  }
  const body = keep.join('\n').replace(/^\[slv_contact\]$/m, '');
  const html = m.parse(body) as string;
  const toc = Array.from(html.matchAll(/<h2 id="([^"]+)">(.*?)<\/h2>/g)).map((x) => ({ id: x[1], text: x[2].replace(/<[^>]+>/g, '') }));
  faqs.forEach((f) => {
    f.aHtml = m.parseInline(f.a) as string;
    f.aPlain = f.a.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/\*\*/g, '');
  });
  return { html, faqs, toc };
}
