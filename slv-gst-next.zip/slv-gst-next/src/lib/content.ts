import pagesJson from '../../content/pages.json';
import postsJson from '../../content/posts.json';

export type Entry = { slug: string; title: string; desc: string; md: string; st?: string };
export type Post = Entry & { cat: string; date: string };

export const pages = pagesJson as Entry[];
export const posts = (postsJson as Post[]).slice().sort((a, b) => (a.date < b.date ? 1 : -1));
export const findPage = (slug: string) => pages.find((p) => p.slug === slug);
export const findPost = (slug: string) => posts.find((p) => p.slug === slug);
export const LAST_UPDATED = '2026-11-10';
